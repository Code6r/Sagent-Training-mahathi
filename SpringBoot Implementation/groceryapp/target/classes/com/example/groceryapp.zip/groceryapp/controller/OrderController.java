package com.example.groceryapp.controller;

import com.example.groceryapp.entity.*;
import com.example.groceryapp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/place/{userId}")
    public Order placeOrder(@PathVariable Long userId) {

        // ✅ Get User
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // ✅ Get Cart
        Cart cart = cartRepository.findByUser_Id(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        // ✅ Get Cart Items
        List<CartItem> cartItems =
                cartItemRepository.findByCart_Id(cart.getId());

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        // ✅ Create Order
        Order order = new Order();
        order.setUser(user);
        order.setTotalAmount(cart.getTotalAmount());
        order.setDiscount(cart.getDiscount());
        order.setFinalAmount(cart.getFinalAmount());
        order.setStatus(OrderStatus.PLACED);

        // 🔥 IMPORTANT FIX (Prevents NullPointerException)
        order.setItems(new ArrayList<>());

        // Save first to generate ID
        order = orderRepository.save(order);

        // ✅ Convert CartItems → OrderItems
        for (CartItem cartItem : cartItems) {

            Product product = cartItem.getProduct();

            if (product.getStock() < cartItem.getQuantity()) {
                throw new RuntimeException("Not enough stock for " + product.getName());
            }

            // Reduce stock
            product.setStock(product.getStock() - cartItem.getQuantity());
            productRepository.save(product);

            // Create OrderItem
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setSubtotal(cartItem.getSubtotal());

            order.getItems().add(orderItem);
        }

        // Save again to persist order items (cascade required)
        order = orderRepository.save(order);

        // ✅ Clear Cart
        cartItemRepository.deleteAll(cartItems);
        cart.setTotalAmount(0);
        cart.setDiscount(0);
        cart.setFinalAmount(0);
        cartRepository.save(cart);

        return order;
    }
}
