package com.example.groceryapp.entity;

public enum OrderStatus {
    PLACED,
    PAID,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
