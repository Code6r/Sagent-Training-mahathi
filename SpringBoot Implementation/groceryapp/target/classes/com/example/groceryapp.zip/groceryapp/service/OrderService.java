package com.example.groceryapp.service;

import com.example.groceryapp.entity.Order;
import com.example.groceryapp.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order placeOrder(Long userId) {

        Order order = new Order();
        order.setStatus("PLACED");
        order.setTotalAmount(500.0);

        return orderRepository.save(order);
    }
}
